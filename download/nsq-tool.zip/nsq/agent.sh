#!/bin/bash

self_name=`basename $0`

for f in `ls nsq*.sh|grep -v "$self_name"`
do 
	echo $f
	source $f
done

app=$1
cmd=$2

if [ "$#" != 2 ] ; then
	echo "agent.sh usage:"
	echo "agent.sh service <start | stop>"
	exit
fi 

case $app in  
nsqadmin) 
		if [ "$cmd" == "start" ]
		then 
			start_nsqlookupd
		else 
			stop_nsqlookupd
		fi ;;
*) 
		echo -e "\e[1;31m service must be admin of <nsqadmin> \e[0m" ;;
esac  

