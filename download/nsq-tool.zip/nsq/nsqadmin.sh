#!/usr/bin/env bash

set -e

function start_admin() {
    APPNAME=nsqadmin
    APPPATH=$PWD/bin
    pwd_dir=$PWD
    
    log_max=`ls logs/$APPNAME*.log|sort -r -t_ -k 2 -n|head -n 1|tr -cd "[0-9]"`
    num=`expr $log_max + 1`
    log_new="logs/$APPNAME"_"$num".log
    nohup "./bin/$APPNAME" --lookupd-http-address=10.213.73.76:4161 --lookupd-http-address=10.213.73.78:4161 > $log_new 2>&1 &
    APP_PID=$!
    echo $APP_PID > "run/$APPNAME.pid"
    echo "start" `date` >> "run/$APPNAME.history"
}

function stop_admin() {
    APPNAME=nsqadmin
    APPPATH=$PWD/bin
    pwd_dir=$PWD

    kill -INT `cat "run/$APPNAME".pid`
    echo "stop" `date` >> "run/$APPNAME.history"
}

