#!/usr/bin/env bash

set -e

function start_lookupd() {
    APPNAME=nsqlookupd
    APPPATH=$PWD/bin
    pwd_dir=$PWD
    
    log_max=`ls logs/$APPNAME*.log|sort -r -t_ -k 2 -n|head -n 1|tr -cd "[0-9]"`
    num=`expr $log_max + 1`
    log_new="logs/$APPNAME"_"$num".log
    nohup "./bin/$APPNAME" > $log_new 2>&1 &
    APP_PID=$!
    echo $APP_PID > "run/$APPNAME.pid"
    echo "start" `date` >> "run/$APPNAME.history"
}

function stop_lookupd() {
    APPNAME=nsqlookupd
    APPPATH=$PWD/bin
    pwd_dir=$PWD

    kill -INT `cat "run/$APPNAME".pid`
    echo "stop" `date` >> "run/$APPNAME.history"
}

