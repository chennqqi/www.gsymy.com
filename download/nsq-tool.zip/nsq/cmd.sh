#!/bin/bash

self_name=`basename $0`

for f in `ls nsq*.sh|grep -v "$self_name"`
do 
	if [ "$f" != "all.sh" ] ; then
	source $f
	fi
done

app=$1
cmd=$2

if [ "$#" != 2 ] ; then
	echo "cmd.sh usage:"
	echo "cmd.sh service <start | stop>"
	exit
fi 

case $app in  
nsqd) 
		if [ "$cmd" == "start" ]
		then 
			start_nsqd
		else 
			stop_nsqd
		fi ;;

nsqadmin) 
		if [ "$cmd" == "start" ]
		then 
			start_admin
		else 
			stop_admin
		fi ;;

nsqlookupd) 
		if [ "$cmd" == "start" ]
		then 
			start_lookupd
		else 
			stop_lookupd
		fi ;;

*) 
		echo -e "\e[1;31m service must be one of <nsqd|nsqadmin|nsqlookupd> \e[0m" ;;
esac  

